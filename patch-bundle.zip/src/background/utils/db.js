import {
  dataUri2text, getScriptHome, getScriptName, getScriptPrettyUrl, getScriptRunAt, getScriptsTags,
  getScriptUpdateUrl, i18n, ignoreChromeErrors, isDataUri, isRemote, isValidHttpUrl,
  makePause, trueJoin,
} from '@/common';
import {
  CACHE_KEYS, FETCH_OPTS, INFERRED, kDownloads, kTag, PROMISE, REQ_KEYS, TIMEOUT_24HOURS,
  TIMEOUT_WEEK, TL_AWAIT, VALUE_IDS,
} from '@/common/consts';
import { deepSize, forEachEntry, forEachKey, forEachValue } from '@/common/object';
import { isGmStorageGranted } from '@/common/script';
import pluginEvents from '../plugin/events';
import broadcast from './broadcast';
import {
  aliveScripts, expandMatchShorthand, getDefaultCustom, getNameURI, inferScriptProps,
  insertMatchLine, newScript, parseMeta, removedScripts, scriptMap, scriptSiteVisited,
  wrapMatchPattern,
} from './script';
import { testBlacklist, testerBatch, testScript } from './tester';
import { getImageData } from './icon';
import { addOwnCommands, addPublicCommands, commands, resolveInit } from './init';
import { installedOver, NEW_INSTALL } from './on-installed';
import patchDB from './patch-db';
import { permissionDownloads } from './permissions';
import { initOptions, kVersion, setOption } from './options';
import sessionData, { flushSession, kScriptSizes, scriptSizes } from './session-data';
import storage, {
  S_CACHE, S_CODE, S_REQUIRE, S_SCRIPT, S_VALUE,
  S_CACHE_PRE, S_CODE_PRE, S_MOD_PRE, S_REQUIRE_PRE, S_SCRIPT_PRE, S_VALUE_PRE,
  getStorageKeys,
} from './storage';
import { storageCacheHas } from './storage-cache';
import { reloadTabForScript } from './tabs';
import { vetUrl } from './url';

let maxScriptId = 0;
let maxScriptPosition = 0;
/** @type {Map<string,number>} */
export let dbKeys = new Map(); // 1: exists, 0: known to be absent
/** Ensuring slow icons don't prevent installation/update */
const ICON_TIMEOUT = 1000;
export const kTryVacuuming = 'Try vacuuming database in options.';
/** Same order as in SIZE_TITLES and getSizes */
export const sizesPrefixRe = RegExp(
  `^(${S_CODE_PRE}|${S_SCRIPT_PRE}|${S_VALUE_PRE}|${S_REQUIRE_PRE}|${S_CACHE_PRE}${S_MOD_PRE})`);
/** @type {{ [type: 'cache' | 'require']: { [url: string]: Promise<?> } }} */
const pendingDeps = { [S_CACHE]: {}, [S_REQUIRE]: {} };
const depsPorts = {};

addPublicCommands({
  GetScriptVer(opts) {
    const script = getScript(opts);
    return script
      ? script.meta.version
      : null;
  },
});

addOwnCommands({
  CheckPosition: sortScripts,
  CheckRemove: checkRemove,
  RemoveScripts: removeScripts,
  GetData: getData,
  GetMoreIds({ url, [kTop]: isTop, [IDS]: ids }) {
    return getScriptsByURL(url, isTop, null, ids);
  },
  /** @return {VMScript} */
  GetScript: getScript,
  GetSizes: getSizes,
  /** @return {Promise<{ items: VMScript[], values? }>} */
  async ExportZip({ values }) {
    const scripts = getScripts();
    const ids = scripts.map(getPropsId);
    const codeMap = await storage[S_CODE].getMulti(ids);
    return {
      items: scripts.map(script => ({ script, code: codeMap[script.props.id] })),
      values: values ? await storage[S_VALUE].getMulti(ids) : undefined,
    };
  },
  /**
   * Adds a single fully-qualified `@match` pattern to a script's code, right after
   * its last existing `@match` line. Used by the popup "+" button and the dashboard's
   * domain-add box. `pattern` may be a bare domain; it's completed via `wrapMatchPattern`.
   * @return {Promise<{ duplicate: boolean, pattern: string } | (ReturnType<typeof parseScript> & { pattern: string })>}
   */
  async AddScriptMatch({ id, pattern }) {
    const wrapped = wrapMatchPattern(pattern);
    if (!wrapped) throw i18n('msgInvalidScript');
    const code = await storage[S_CODE].getOne(id);
    const result = insertMatchLine(code, wrapped);
    if (!result.added) return { duplicate: result.duplicate, pattern: wrapped };
    const res = await parseScript({
      id,
      code: result.code,
      bumpDate: true,
      message: '', // shown as a toast by the caller instead of the easily-truncated row text
    });
    res.pattern = wrapped;
    return res;
  },
  /** @return {Promise<string>} */
  GetScriptCode(id) {
    return storage[S_CODE][Array.isArray(id) ? 'getMulti' : 'getOne'](id);
  },
  GetTags: () => getScriptsTags(aliveScripts),
  /** @return {Promise<void>} */
  async MarkRemoved({ id, removed }) {
    if (!removed) {
      const script = getScriptById(id);
      const conflict = getScript({ meta: script.meta });
      if (conflict) throw i18n('msgNamespaceConflictRestore');
    }
    await updateScriptInfo(id, {
      config: { removed: removed ? 1 : 0 },
      props: { lastModified: Date.now() },
    });
    const list = removed ? aliveScripts : removedScripts;
    const i = list.findIndex(script => script.props.id === id);
    const [script] = list.splice(i, 1);
    (removed ? removedScripts : aliveScripts).push(script);
  },
  /** @return {Promise<number>} */
  Move({ id, offset }) {
    const script = getScriptById(id);
    const index = aliveScripts.indexOf(script);
    aliveScripts.splice(index, 1);
    aliveScripts.splice(index + offset, 0, script);
    return normalizePosition();
  },
  ParseMeta: parseMetaWithErrors,
  ParseMetaErrors: data => parseMetaWithErrors(data).errors,
  ParseScript: parseScript,
  /** @return {Promise<void>} */
  UpdateScriptInfo({ id, config, custom }) {
    return updateScriptInfo(id, {
      config,
      custom,
      props: { lastModified: Date.now() },
    });
  },
  /** @return {Promise<number>} */
  Vacuum: vacuum,
});

export async function initializeDatabase(reset) {
  if (reset) {
    maxScriptId = 0;
    maxScriptPosition = 0;
    dbKeys.clear();
    aliveScripts.length = 0;
    removedScripts.length = 0;
    scriptSizes = {}; // eslint-disable-line no-import-assign
    for (const key in scriptMap) delete scriptMap[key];
    for (const key in scriptSiteVisited) delete scriptSiteVisited[key];
  }
  /** @type {string[]} */
  let keys;
  let [allKeys, data] = await Promise.all([
    getStorageKeys?.(),
    !getStorageKeys && storage.api.get(),
    sessionData,
  ]);
  if (allKeys) {
    // Filtering and creating Map in atomic native code operations instead of js loop
    keys = allKeys.join('\n').replace(/^(?:(options|version|(?:scr|mod):\d+)|\S+)$/gm, '$1').trim();
    dbKeys = new Map(JSON.parse(`[${keys.replace(/\S+/g, '["$&",1],').slice(0, -1)}]`));
    keys = keys.split(/\n+/);
    data = await storage.api.get(keys);
  }
  if (installedOver === NEW_INSTALL) await patchDB();
  if (installedOver) storage.api.set({ [kVersion]: __.VM_VER });
  const uriMap = {};
  const defaultCustom = getDefaultCustom();
  data::forEachEntry(([key, script]) => {
    const id = +storage[S_SCRIPT].toId(key);
    if (id && script) {
      const uri = getNameURI(script);
      // Only check ID/namespace conflicts for scripts not removed
      if (!script.config.removed) {
        if (scriptMap[id] && scriptMap[id] !== script) {
          // ID conflicts!
          // Should not happen, discard duplicates.
          return;
        }
        if (uriMap[uri]) {
          // Namespace conflicts!
          // Should not happen, discard duplicates.
          return;
        }
        uriMap[uri] = script;
      }
      script.props = {
        ...script.props,
        id,
        uri,
      };
      const custom = script.custom = { ...defaultCustom, ...script.custom };
      const { pathMap, tags } = custom;
      const meta = script.meta ||= {};
      const tag = meta[kTag];
      if (tags) {
        custom[kTag] = tags.split(/\s+/);
        delete custom.tags;
      }
      if (tag && !Array.isArray(tag) /* script installed in an older VM */) {
        meta[kTag] = tag.split(/\s+/);
      }
      // Patching the bug in 2.27.0 where data: URI was saved as invalid in pathMap
      if (pathMap) for (const url in pathMap) if (isDataUri(url)) delete pathMap[url];
      maxScriptId = Math.max(maxScriptId, id);
      maxScriptPosition = Math.max(maxScriptPosition, getInt(script.props.position));
      (script.config.removed ? removedScripts : aliveScripts).push(script);
      // listing all known resource urls in order to remove unused mod keys
      if (!meta.require) meta.require = [];
      if (!meta.resources) meta.resources = {};
      if (TL_AWAIT in meta) meta[TL_AWAIT] = true; // a string if the script was saved in old VM
      meta.grant = [...new Set(meta.grant || [])]; // deduplicate
    }
  });
  initOptions(data, installedOver, installedOver && installedOver !== NEW_INSTALL);
  if (__.DEBUG) {
    console.info('store:', {
      aliveScripts, removedScripts, maxScriptId, maxScriptPosition, scriptMap, scriptSizes,
    });
  }
  if (!__.MV3 || !sessionData.init) {
    if (allKeys?.length) {
      const set = new Set(keys); // much faster lookup
      const data2 = await storage.api.get(allKeys.filter(k => !set.has(k)));
      Object.assign(data, data2);
    }
    vacuum(data); // also calculates `scriptSizes`
    checkRemove();
    sortScripts();
  }
  if (!__.MV3) {
    setInterval(checkRemove, TIMEOUT_24HOURS);
  }
  resolveInit();
}

initializeDatabase();

/** @return {number} */
function getInt(val) {
  return +val || 0;
}

/** @return {?number} */
function getPropsId(script) {
  return script?.props.id;
}

/** @return {void} */
function updateLastModified() {
  setOption('lastModified', Date.now());
}

/** @return {Promise<boolean>} */
export async function normalizePosition() {
  const updates = aliveScripts.reduce((res, script, index) => {
    const { props } = script;
    const position = index + 1;
    if (props.position !== position) {
      props.position = position;
      (res || (res = {}))[props.id] = script;
    }
    return res;
  }, null);
  maxScriptPosition = aliveScripts.length;
  if (updates) {
    await storage[S_SCRIPT].set(updates);
    updateLastModified();
  }
  return !!updates;
}

/** @return {Promise<Boolean>} */
export async function sortScripts() {
  const old = [...aliveScripts];
  aliveScripts.sort((a, b) => (a.props.position || 0) - (b.props.position || 0));
  if (await normalizePosition() || old.some((val, i) => val !== aliveScripts[i])) {
    broadcast('ScriptsUpdated');
    return true;
  }
}

/** @return {?VMScript} */
export function getScriptById(id) {
  return scriptMap[id];
}

export function getScriptsByIdsOrAll(ids) {
  return ids?.map(getScriptById) ?? [...aliveScripts, ...removedScripts];
}

/** @return {?VMScript} */
export function getScript({ id, uri, meta, removed }) {
  let script;
  if (id) {
    script = getScriptById(id);
  } else {
    if (!uri) uri = getNameURI({ meta, props: { id: '@@should-have-name' } });
    script = (removed ? removedScripts : aliveScripts).find(({ props }) => uri === props.uri);
  }
  return script;
}

/** @return {VMScript[]} */
export function getScripts() {
  return [...aliveScripts];
}

const makeEnv = () => ({
  depsMap: {},
  [RUN_AT]: {},
  [SCRIPTS]: [],
});
const STORAGE_ROUTES = {
  [S_CACHE]: CACHE_KEYS,
  [S_CODE]: IDS,
  [S_REQUIRE]: REQ_KEYS,
  [S_VALUE]: VALUE_IDS,
};
const STORAGE_ROUTES_ENTRIES = Object.entries(STORAGE_ROUTES);
const notifiedBadScripts = new Set();

/**
 * @desc Get scripts to be injected to page with specific URL.
 * @param {string} url
 * @param {boolean} isTop
 * @param {Array} [errors] - omit to enable EnvDelayed mode
 * @param {Object} [prevIds] - used by the popup to return an object with only new ids
 *   (disabled, newly installed, non-matching due to SPA navigation)
 * @return {VMInjection.EnvStart | VMInjection.EnvDelayed | Object | void }
 */
export function getScriptsByURL(url, isTop, errors, prevIds) {
  if (testBlacklist(url)) return;
  const allIds = {};
  const isDelayed = !errors;
  /** @type {VMInjection.EnvStart} */
  let envStart;
  /** @type {VMInjection.EnvDelayed} */
  let envDelayed;
  let clipboardChecked = isDelayed || !IS_FIREFOX;
  testerBatch(errors || true);
  for (const script of aliveScripts) {
    const {
      config: { enabled },
      custom,
      meta,
      props: { id },
    } = script;
    if ((prevIds ? id in prevIds : !enabled)
    || !((isTop || !(custom.noframes ?? meta.noframes)) && testScript(url, script))) {
      continue;
    }
    if (prevIds) {
      allIds[id] = enabled ? MORE : 0;
      continue;
    }
    allIds[id] = 1;
    if (!envStart) {
      envStart = makeEnv();
      envDelayed = makeEnv();
      for (const [areaName, listName] of STORAGE_ROUTES_ENTRIES) {
        envStart[areaName] = {}; envDelayed[areaName] = {};
        envStart[listName] = []; envDelayed[listName] = [];
      }
    }
    const { pathMap = buildPathMap(script) } = custom;
    const runAt = getScriptRunAt(script);
    const env = runAt === 'start' || runAt === 'body' ? envStart : envDelayed;
    const { depsMap } = env;
    env[IDS].push(id);
    env[RUN_AT][id] = runAt;
    if (isGmStorageGranted(meta)) {
      env[VALUE_IDS].push(id);
    }
    if (!clipboardChecked) {
      for (const g of meta.grant) {
        if (!clipboardChecked && (g === 'GM_setClipboard' || g === 'GM.setClipboard')) {
          clipboardChecked = envStart.clipFF = true;
        }
      }
    }
    for (const [list, name, dataUriDecoder] of [
      [meta.require, S_REQUIRE, dataUri2text],
      [Object.values(meta.resources), S_CACHE],
    ]) {
      const listName = STORAGE_ROUTES[name];
      const envCheck = name === S_CACHE ? envStart : env; // envStart cache is reused in injected
      // eslint-disable-next-line no-shadow
      for (let url of list) {
        url = pathMap[url] || url;
        if (url) {
          if (isDataUri(url)) {
            if (dataUriDecoder) {
              env[name][url] = dataUriDecoder(url);
            }
          } else if (!envCheck[listName].includes(url)) {
            env[listName].push(url);
            (depsMap[url] || (depsMap[url] = [])).push(id);
          }
        }
      }
    }
    env[SCRIPTS].push(script);
  }
  testerBatch();
  if (prevIds) {
    return allIds;
  }
  if (!envStart) {
    return;
  }
  if (isDelayed) {
    envDelayed[PROMISE] = readEnvironmentData(envDelayed);
    return envDelayed;
  }
  if (envStart[IDS].length) {
    envStart[PROMISE] = readEnvironmentData(envStart);
  }
  if (envDelayed[IDS].length) {
    envDelayed[PROMISE] = makePause().then(readEnvironmentData.bind(null, envDelayed));
  }
  return Object.assign(envStart, { allIds, [MORE]: envDelayed });
}

async function readEnvironmentData(env) {
  const keys = [];
  for (const [area, listName] of STORAGE_ROUTES_ENTRIES) {
    for (const id of env[listName]) {
      keys.push(storage[area].toKey(id));
    }
  }
  const data = await storage.api.get(keys);
  const badScripts = new Set();
  for (const [area, listName] of STORAGE_ROUTES_ENTRIES) {
    for (const id of env[listName]) {
      let val = data[storage[area].toKey(id)];
      if (!val && area === S_VALUE) val = {};
      // {} enables tracking in addValueOpener
      env[area][id] = val;
      if (val == null) {
        if (area === S_CODE) {
          badScripts.add(id);
        } else {
          env.depsMap[id]?.forEach(scriptId => badScripts.add(scriptId));
        }
      }
    }
  }
  if (badScripts.size) {
    reportBadScripts(badScripts);
  }
  return env;
}

/** @param {Set<number>} ids */
function reportBadScripts(ids) {
  const unnotifiedIds = [];
  const title = i18n('msgMissingResources');
  let toLog = i18n('msgReinstallScripts');
  let toNotify = toLog;
  let str;
  ids.forEach(id => {
    str = `\n#${id}: ${getScriptName(getScriptById(id))}`;
    toLog += str;
    if (!notifiedBadScripts.has(id)) {
      notifiedBadScripts.add(id);
      unnotifiedIds.push(id);
      toNotify += str;
    }
  });
  console.error(`${title} ${toLog}`);
  if (unnotifiedIds.length) {
    notifyToOpenScripts(title, toNotify, unnotifiedIds);
  }
}

export function notifyToOpenScripts(title, text, ids) {
  // FF doesn't show notifications of type:'list' so we'll use `text` everywhere
  commands.Notification({ title, text, onclick: { cmd: 'OpenEditor', for: ids } });
}

/**
 * @desc Get data for dashboard.
 * @return {Promise<{ scripts: VMScript[], cache: Object }>}
 */
export async function getData({ id, ids, sizes }) {
  if (id) ids = [id];
  const res = {};
  const scripts = ids
    // Some ids shown in popup/editor may have been hard-deleted
    ? getScriptsByIdsOrAll(ids).filter(Boolean)
    : getScriptsByIdsOrAll();
  scripts.forEach(inferScriptProps);
  res[kDownloads] = permissionDownloads;
  res[SCRIPTS] = scripts;
  if (sizes) res.sizes = getSizes(ids);
  if (!id) res.cache = await getIconCache(scripts);
  if (!id && sizes) res.sync = commands.SyncGetStates();
  return res;
}

/**
 * Returns only own icon and the already cached icons.
 * The rest are prefetched in background and will be used by loadScriptIcon.
 * @param {VMScript[]} scripts
 * @return {Promise<{}>}
 */
async function getIconCache(scripts) {
  // data uri for own icon to load it instantly in Chrome when there are many images
  const toGet = [`${ICON_PREFIX}38.png`];
  const toPrime = [];
  const res = {};
  for (let { custom, meta } of scripts) {
    let icon = custom.icon || meta.icon;
    if (isValidHttpUrl(icon)) {
      icon = custom.pathMap[icon] || icon;
      toGet.push(icon);
      if (!storageCacheHas(S_CACHE_PRE + icon)) toPrime.push(icon);
    }
  }
  if (toPrime.length) {
    await storage[S_CACHE].getMulti(toPrime);
  }
  for (let i = 0, d, url; i < toGet.length; i++) {
    url = toGet[i];
    d = getImageData(url);
    if (!isObject(d) || !i && (d = await d)) {
      res[url] = d;
    }
  }
  return res;
}

/**
 * @param {number[]} [ids]
 * @return {number[][]}
 */
export function getSizes(ids) {
  const scripts = getScriptsByIdsOrAll(ids);
  return scripts.map(({
    meta,
    custom: { pathMap = {} },
    props: { id },
  }, i) => [
    // Same order as SIZE_TITLES and sizesPrefixRe
    scriptSizes[S_CODE_PRE + id] || 0,
    deepSize(scripts[i]),
    scriptSizes[S_VALUE_PRE + id] || 0,
    meta.require.reduce(getSizeForRequires, { len: 0, pathMap }).len,
    Object.values(meta.resources).reduce(getSizeForResources, { len: 0, pathMap }).len,
  ]);
}

function getSizeForRequires(accum, url) {
  accum.len += (scriptSizes[S_REQUIRE_PRE + (accum.pathMap[url] || url)] || 0) + url.length;
  return accum;
}

function getSizeForResources(accum, url) {
  accum.len += (scriptSizes[S_CACHE_PRE + (accum.pathMap[url] || url)] || 0) + url.length;
  return accum;
}

export async function removeScripts(ids) {
  const idsToRemove = [];
  // Only those marked as removed can be removed permanently
  const newLen = 1 + removedScripts.reduce((iAlive, script, i) => {
    const id = getPropsId(script);
    if (ids.includes(id)) {
      idsToRemove.push(S_CODE_PRE + id, S_SCRIPT_PRE + id, S_VALUE_PRE + id);
      delete scriptMap[id];
    } else if (++iAlive < i) removedScripts[iAlive] = script;
    return iAlive;
  }, -1);
  if (removedScripts.length !== newLen) {
    removedScripts.length = newLen; // live scripts were moved to the beginning
    await storage.api.remove(idsToRemove);
    vacuum();
    return broadcast('RemoveScripts', ids);
  }
}

export function checkRemove({ force } = {}) {
  const now = Date.now();
  const ids = removedScripts.filter(script => {
    const { lastModified } = script.props;
    return script.config.removed && (force || now - getInt(lastModified) > TIMEOUT_WEEK);
  }).map(script => script.props.id);
  return removeScripts(ids);
}

/**
 * @param {number} id
 * @param {DeepPartial<VMScript>} data
 */
export async function updateScriptInfo(id, data) {
  const script = scriptMap[id];
  for (const key in data) { // shallow merge
    if (script[key]) Object.assign(script[key], data[key]);
  }
  await Promise.all([
    storage.api.set({ [S_SCRIPT_PRE + id]: script }),
    broadcast('UpdateScript', { where: { id }, update: script }),
  ]);
}

/**
 * @param {string | {code:string, custom:VMScript['custom']}} src
 * @return {{ meta: VMScript['meta'], errors: string[] }}
 */
function parseMetaWithErrors(src) {
  const isObj = isObject(src);
  const custom = isObj && src.custom || getDefaultCustom();
  const errors = [];
  const meta = parseMeta(isObj ? src.code : src, { errors });
  if (meta) {
    if (meta.grant.includes('none') && new Set(meta.grant).size > 1) {
      errors.push(i18n('hintGrantNone'));
    }
    testerBatch(errors);
    testScript('', { meta, custom });
    testerBatch();
  } else {
    errors.push(i18n('labelNoName')); // used by confirm app
  }
  return {
    meta,
    errors: errors.length ? errors : null,
  };
}

/**
 * @param {VMScriptSourceOptions} src
 * @return {Promise<{
 *   errors: string[],
 *   isNew: boolean,
 *   update: VMScript & { message: string },
 *   where: { id: number },
 * }>}
 */
export async function parseScript(src) {
  if (src.code != null && !src.meta) {
    src.code = expandMatchShorthand(src.code);
  }
  const { meta, errors } = src.meta ? src : parseMetaWithErrors(src);
  if (!meta.name) throw `${i18n('msgInvalidScript')}\n${i18n('labelNoName')}`;
  const update = {
    message: src.message == null ? i18n('msgUpdated') : src.message || '',
  };
  const result = { errors, update };
  const { [S_CODE]: code, update: srcUpdate } = src;
  const now = Date.now();
  let { id } = src;
  let script;
  let oldScript = getScript({ id, meta });
  if (oldScript) {
    script = oldScript;
    id = script.props.id;
  } else {
    script = newScript();
    maxScriptId++;
    id = script.props.id = maxScriptId;
    result.isNew = true;
    update.message = i18n('msgInstalled');
    aliveScripts.push(script);
  }
  const { config, custom, props } = script;
  const uri = getNameURI({ meta, props: {id} });
  if (oldScript) {
    // Do not allow script with same name and namespace
    if (src.isNew || id && aliveScripts.some(({ props: p }) => uri === p.uri && id !== p.id)) {
      throw i18n('msgNamespaceConflict');
    }
    delete script[INFERRED];
  }
  props.lastModified = now;
  props.uuid = props.uuid || crypto.randomUUID();
  // Overwriting inner data by `src`, deleting keys for which `src` specifies `null`
  for (const key of ['config', 'custom', 'props']) {
    const dst = script[key];
    src[key]::forEachEntry(([srcKey, srcVal]) => {
      if (srcVal == null) delete dst[srcKey];
      else dst[srcKey] = srcVal;
    });
  }
  const pos = +src.position;
  if (pos) {
    props.position = pos;
    maxScriptPosition = Math.max(maxScriptPosition, pos);
  } else if (!oldScript) {
    maxScriptPosition++;
    props.position = maxScriptPosition;
  }
  config.enabled = getInt(config.enabled);
  config.removed = 0; // force-resetting `removed` since this is an installation
  config.shouldUpdate = getInt(config.shouldUpdate);
  script.meta = meta;
  props.uri = getNameURI(script); // DANGER! Must be after props.position and meta assignments.
  delete custom.from; // remove the old installation URL if any
  if (!getScriptHome(script) && isRemote(src.from)) {
    custom.from = src.from; // to avoid overriding script's `meta` for homepage in a future version
  }
  // Allowing any http url including localhost as the user may keep multiple scripts there
  if (isValidHttpUrl(src.url)) custom.lastInstallURL = src.url;
  if (!srcUpdate) storage.mod.remove(getScriptUpdateUrl(script, { all: true }) || []);
  buildPathMap(script, src.url);
  const depsPromise = fetchResources(script, src);
  // DANGER! Awaiting here when all props are set to avoid modifications made by a "concurrent" call
  const codeChanged = !oldScript || code !== await storage[S_CODE].getOne(id);
  if (codeChanged && src.bumpDate) props.lastUpdated = now;
  // Installer has all the deps, so we'll put them in storage first
  if (src.cache) await depsPromise;
  await storage.api.set({
    [S_SCRIPT_PRE + id]: script,
    ...codeChanged && { [S_CODE_PRE + id]: code },
  });
  inferScriptProps(script);
  Object.assign(update, script, srcUpdate);
  result.where = { id };
  result[S_CODE] = src[S_CODE];
  broadcast('UpdateScript', result);
  pluginEvents.emit('scriptChanged', result);
  if (src.reloadTab) reloadTabForScript(script);
  return result;
}

/** @return {Object} */
function buildPathMap(script, base) {
  const { meta } = script;
  const baseUrl = base || script.custom.lastInstallURL;
  const pathMap = baseUrl ? [
    ...meta.require,
    ...Object.values(meta.resources),
    meta.icon,
  ].reduce((map, key) => {
    if (key) {
      const fullUrl = vetUrl(key, baseUrl);
      if (fullUrl !== key) map[key] = fullUrl;
    }
    return map;
  }, {}) : {};
  script.custom.pathMap = pathMap;
  return pathMap;
}

/**
 * @param {VMScript} script
 * @param {VMScriptSourceOptions} src
 * @return {Promise<?string>} error text
 */
export async function fetchResources(script, src) {
  const { custom, meta } = script;
  const { pathMap } = custom;
  const { resources } = meta;
  const icon = custom.icon || meta.icon;
  const jobs = [];
  for (const url of meta.require) {
    jobs.push([S_REQUIRE, url]);
  }
  for (const key in resources) {
    jobs.push([S_CACHE, resources[key]]);
  }
  if (isRemote(icon)) {
    jobs.push([S_CACHE, icon, ICON_TIMEOUT]);
  }
  if (!jobs.length) {
    return;
  }
  for (let i = 0, type, url, timeout, res; i < jobs.length; i++) {
    [type, url, timeout] = jobs[i];
    if (!(res = pendingDeps[type][url])) {
      if (url && !isDataUri(url)) {
        url = pathMap[url] || url;
        if ((res = src[type]) && (res = res[url]) != null) {
          storage[type].setOne(url, res);
          res = '';
        } else {
          res = fetchResource(src, type, url);
          if (timeout) res = Promise.race([res, makePause(timeout)]);
          pendingDeps[type][url] = res;
        }
      }
    }
    jobs[i] = res;
  }
  const errors = await Promise.all(jobs);
  const error = errors.map(formatHttpError)::trueJoin('\n');
  if (error) {
    let message = i18n('msgErrorFetchingResource');
    broadcast('UpdateScript', {
      update: { error, message },
      where: { id: getPropsId(script) },
    });
    message += '\n' + error;
    return src.force
      ? { script, text: message }
      : message;
  }
}

/**
 * @param {VMScriptSourceOptions} src
 * @param {string} type
 * @param {string} url
 * @return {Promise<?>}
 */
async function fetchResource(src, type, url) {
  let res;
  if (!isRemote(url)
  || src.update
  || await storage[type].getOne(url) == null) {
    const { portId } = src;
    if (portId) postToPort(depsPorts, portId, [url]);
    try {
      await storage[type].fetch(url, src[FETCH_OPTS]);
    } catch (err) {
      res = err;
    }
    if (portId) postToPort(depsPorts, portId, [url, true]);
  }
  delete pendingDeps[type][url];
  return res;
}

function postToPort(ports, id, msg) {
  let p = ports[id];
  if (!p) {
    p = ports[id] = chrome.runtime.connect({ name: id });
    p.onDisconnect.addListener(() => {
      ignoreChromeErrors();
      delete ports[id];
    });
  }
  p.postMessage(msg);
}

function formatHttpError(e) {
  return e && [e.status && `HTTP${e.status}`, e.url]::trueJoin(' ') || e;
}

let _vacuuming;
/**
 * @param {Object} [data]
 * @return {Promise<{errors:string[], fixes:number}>}
 */
export async function vacuum(data) {
  if (_vacuuming) return _vacuuming;
  let resolveSelf;
  _vacuuming = new Promise(r => { resolveSelf = r; });
  const noFetch = data && [];
  const sizes = {};
  const result = {};
  const toFetch = [];
  const errors = result.errors = [];
  const keysToRemove = [];
  /** -1=untouched, 1=touched, 2(+scriptId)=missing */
  const status = {};
  const prefixRe = RegExp(`^(${[
    S_VALUE_PRE,
    S_CACHE_PRE,
    S_REQUIRE_PRE,
    S_CODE_PRE,
    S_MOD_PRE,
  ].join('|')})`);
  const prefixIgnoreMissing = [
    S_VALUE_PRE,
    S_MOD_PRE,
  ];
  const downloadUrls = {};
  const touch = (prefix, id, scriptId, pathMap) => {
    if (!id || pathMap && isDataUri(id)) {
      return 0;
    }
    const key = prefix + (pathMap?.[id] || id);
    const val = status[key];
    if (val < 0) {
      status[key] = 1;
      if (id !== scriptId) {
        status[S_MOD_PRE + id] = 1;
      }
      if (prefix === S_VALUE_PRE) {
        if ((sizes[key] = deepSize(data[key])) === 2) {
          // remove empty {}
          sizes[key] = 0;
          status[key] = -1;
        }
      } else if (prefix !== S_MOD_PRE) {
        sizes[key] = deepSize(data[key]) + key.length;
      }
    } else if (!val && !prefixIgnoreMissing.includes(prefix)) {
      status[key] = 2 + scriptId;
    }
  };
  if (!data) data = await storage.api.get();
  data::forEachKey((key) => {
    if (prefixRe.test(key)) {
      status[key] = -1;
    }
  });
  scriptSizes = sizes; // eslint-disable-line no-import-assign
  if (__.MV3) flushSession(kScriptSizes, scriptSizes);
  getScriptsByIdsOrAll().forEach((script) => {
    const { meta, props } = script;
    const icon = script.custom.icon || meta.icon;
    const { id } = props;
    const pathMap = script.custom.pathMap || buildPathMap(script);
    const updUrls = getScriptUpdateUrl(script, { all: true });
    if (updUrls) {
      updUrls.forEach(url => touch(S_MOD_PRE, url, id));
      downloadUrls[id] = updUrls[0];
    }
    touch(S_CODE_PRE, id, id);
    touch(S_MOD_PRE, id, id);
    touch(S_VALUE_PRE, id, id);
    meta.require.forEach(url => touch(S_REQUIRE_PRE, url, id, pathMap));
    meta.resources::forEachValue(url => touch(S_CACHE_PRE, url, id, pathMap));
    if (isRemote(icon)) touch(S_CACHE_PRE, icon, id, pathMap);
  });
  status::forEachEntry(([key, value]) => {
    if (value < 0) {
      // Removing redundant value
      keysToRemove.push(key);
    } else if (value >= 2) {
      // Downloading the missing code or resource
      const area = storage.forKey(key);
      const id = area.toId(key);
      const url = area.name === S_CODE ? downloadUrls[id] : id;
      if (noFetch) {
        noFetch.push(url || +id && getScriptPrettyUrl(getScriptById(id)) || key);
      } else if (url && area.fetch) {
        keysToRemove.push(S_MOD_PRE + url);
        toFetch.push(area.fetch(url).catch(err => errors.push(`${
          getScriptName(getScriptById(+id || value - 2))
        }: ${
          formatHttpError(err)
        }`)));
      }
    }
  });
  if (keysToRemove.length) {
    await storage.api.remove(keysToRemove); // Removing `mod` before fetching
    await Promise.all(toFetch);
  }
  if (noFetch && noFetch.length) {
    console.warn('Missing required resources. ' + kTryVacuuming, noFetch);
  }
  _vacuuming = null;
  result.fixes = toFetch.length + keysToRemove.length;
  resolveSelf(result);
  return result;
}
