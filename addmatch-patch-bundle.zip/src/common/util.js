// SAFETY WARNING! Exports used by `injected` must make ::safe() calls and use __proto__:null

import { BLOB_LIFE, U8_fromBase64 } from '@/common/consts';
import { makePause } from '.';

export const i18n = memoize((name, args) => chrome.i18n.getMessage(name, args) || name);
/** Caps a string for one-line toasts/banners where there's no room for the full name. */
export function truncateText(text, max = 24) {
  return text && text.length > max ? `${text.slice(0, max - 1)}\u2026` : text || '';
}
const HAS_BASE64_RE = /(^|;)\s*base64\s*(;|$)/;
const NON_ASCII_RE = /[\x80-\xFF]/;

export function memoize(func) {
  const cacheMap = /*@__PURE__*/Object.create(null);
  function memoized(...args) {
    const key = args.length === 1 ? `${args[0]}` : JSON.stringify(args);
    const res = cacheMap[key];
    return res !== undefined || hasOwnProperty(cacheMap, key)
      ? res
      : (cacheMap[key] = safeApply(func, this, args));
  }
  return __.DEV
    ? Object.defineProperty(memoized, 'name', { value: func.name + ':memoized' })
    : memoized;
}

export function debounce(func, time) {
  let startTime;
  let timer;
  let callback;
  time = Math.max(0, +time || 0);
  function checkTime() {
    timer = null;
    if (performance.now() >= startTime) callback();
    else checkTimer();
  }
  function checkTimer() {
    if (!timer) {
      const delta = startTime - performance.now();
      timer = setTimeout(checkTime, delta);
    }
  }
  function debouncedFunction(...args) {
    startTime = performance.now() + time;
    callback = () => {
      callback = null;
      func.apply(this, args);
    };
    checkTimer();
  }
  return debouncedFunction;
}

export function throttle(func, time) {
  let lastTime = 0;
  time = Math.max(0, +time || 0);
  function throttledFunction(...args) {
    const now = performance.now();
    if (lastTime + time < now) {
      lastTime = now;
      func.apply(this, args);
    }
  }
  return throttledFunction;
}

export function noop() {}

export function getUniqId(prefix = 'VM', idSafe) {
  let res = crypto.getRandomValues(new Uint8Array(12));
  if (U8_fromBase64) { // minimum_chrome_version>=140, strict_min_version>=133
    res = res.toBase64({ alphabet: 'base64url', omitPadding: true });
    if (idSafe) res = res.replaceAll('-', '$');
  } else {
    res = btoa(String.fromCharCode(...res));
    if (idSafe) res = res.replace(/\+/g, '$').replace(/\//g, '_').replace(/=+/, '');
  }
  return prefix + res;
}

/**
 * @param {ArrayBuffer|Uint8Array|Array} buf
 * @return {string} a binary string i.e. one byte per character
 */
export function buffer2string(buf) {
  const arrayLen = buf.length; // present on Uint8Array/Array
  if (U8_fromBase64) { // 3x faster even with the extra string for GC
    return atob((arrayLen != null ? buf : new Uint8Array(buf)).toBase64());
  }
  // The max number of arguments varies between JS engines but it's >32k so we're safe
  const sliceSize = 8192;
  const slices = [];
  const end = arrayLen || buf.byteLength;
  const needsSlicing = arrayLen == null || end > sliceSize;
  for (let offset = 0; offset < end; offset += sliceSize) {
    slices.push(String.fromCharCode.apply(null,
      needsSlicing
        ? new Uint8Array(arrayLen ? buf.buffer : buf, offset, Math.min(sliceSize, end - offset))
        : buf));
  }
  return slices.join('');
}

/**
 * Faster than buffer2string+btoa: 2x in Chrome, 10x in FF
 * @param {Blob} blob
 * @param {number} [offset]
 * @param {number} [length]
 * @return {string | Promise<string>} base64-encoded contents
 */
export function blob2base64(blob, offset = 0, length = 1e99) {
  if (offset || length < blob.size) {
    blob = blob.slice(offset, offset + length);
  }
  if (!blob.size) {
    return '';
  }
  if (U8_fromBase64) {
    // Not using {alphabet: 'base64url'} because a data URI uses standard base64 encoding
    return blob.arrayBuffer().then(buf => new Uint8Array(buf).toBase64());
  }
  return readBlob(blob).then(res => res.slice(res.indexOf(',') + 1));
}

export function dataUri2text(url) {
  const i = url.indexOf(','); // a non-base64 data: uri may have many `,`
  const meta = url.slice(0, i);
  const body = url.slice(i + 1);
  const isB64 = HAS_BASE64_RE.test(meta);
  const decoded = isB64 ? atob(body) : decodeURIComponent(body);
  return NON_ASCII_RE.test(decoded)
    ? new TextDecoder().decode(string2uint8array(decoded, isB64 && body))
    : decoded;
}

export function string2uint8array(str, b64str) {
  if (b64str) {
    if (U8_fromBase64) return U8_fromBase64(b64str);
    str ??= atob(b64str);
  }
  // 5x times faster than fetch() which serializes+deserializes the result over IPC
  const len = str.length;
  const array = new Uint8Array(len);
  for (let i = 0; i < len; i += 1) {
    array[i] = str.charCodeAt(i);
  }
  return array;
}

const VERSION_RE = /^(.*?)-([-.0-9a-z]+)|$/i;
const DIGITS_RE = /^\d+$/; // using regexp to avoid +'1e2' being parsed as 100

/** @return -1 | 0 | 1 */
export function compareVersion(ver1, ver2) {
  // Used in safe context
  // eslint-disable-next-line no-restricted-syntax
  const [, main1 = ver1 || '', pre1] = VERSION_RE.exec(ver1);
  // eslint-disable-next-line no-restricted-syntax
  const [, main2 = ver2 || '', pre2] = VERSION_RE.exec(ver2);
  const delta = compareVersionChunk(main1, main2)
    || !pre1 - !pre2 // 1.2.3-pre-release is less than 1.2.3
    || pre1 && compareVersionChunk(pre1, pre2, true); // if pre1 is present, pre2 is too
  return delta < 0 ? -1 : +!!delta;
}

function compareVersionChunk(ver1, ver2, isSemverMode) {
  const parts1 = ver1.split('.');
  const parts2 = ver2.split('.');
  const len1 = parts1.length;
  const len2 = parts2.length;
  const len = (isSemverMode ? Math.min : Math.max)(len1, len2);
  let delta;
  for (let i = 0; !delta && i < len; i += 1) {
    const a = parts1[i];
    const b = parts2[i];
    if (isSemverMode) {
      delta = DIGITS_RE.test(a) && DIGITS_RE.test(b)
        ? a - b
        : a > b || a < b && -1;
    } else {
      delta = (parseInt(a, 10) || 0) - (parseInt(b, 10) || 0);
    }
  }
  return delta || isSemverMode && (len1 - len2);
}

const units = [
  ['min', 60],
  ['h', 24],
  ['d', 1000, 365],
  ['y'],
];
export function formatTime(duration) {
  duration /= 60 * 1000;
  const unitInfo = units.find((item) => {
    const max = item[1];
    if (!max || duration < max) return true;
    const step = item[2] || max;
    duration /= step;
    return false;
  });
  return `${duration | 0}${unitInfo[0]}`;
}

export function formatByteLength(len, noBytes) {
  if (!len) return '';
  if (len < 1024 && !noBytes) return `${len} B`;
  if ((len /= 1024) < 1024) return `${Math.round(len)} k`;
  return `${+(len / 1024).toFixed(1)} M`;
}

// Used by `injected`
export function isEmpty(obj) {
  for (const key in obj) {
    if (hasOwnProperty(obj, key)) {
      return false;
    }
  }
  return true;
}

export function ensureArray(data) {
  return Array.isArray(data) ? data : [data];
}

const isDataUriRe = /^data:/i;
const isHttpOrHttpsRe = /^https?:\/\//i;
const isLocalUrlRe = regex('i')`^(
  file:|
  about:|
  data:|
  https?://
    ([^@\/]*@)?
    (
      localhost|
      127\.0\.0\.1|
      (192\.168|172\.16|10\.0)\.\d+\.\d+|
      \[(::1|(fe80|fc00)::[.:0-9a-f]+)\]|
      [^\/:]+\.(test|example|invalid|localhost)
    )
    (:\d+|/|$)
)`;
/** Cherry-picked from https://greasyfork.org/en/help/cdns */
export const isCdnUrlRe = regex('i')`^https://(
  (\w+-)?cdn(js)?(-\w+)?\.[^\/]+ |
  bundle\.run |
  (www\.)?gitcdn\.\w+ |
  (
    ajax\.aspnetcdn |
    apis\.google |
    apps\.bdimg |
    caiyunapp |
    code\.(bdstatic | jquery) |
    kit\.fontawesome |
    lib\.baomitu |
    libs\.baidu |
    npm\.elemecdn |
    registry\.npmmirror |
    static\.(hdslb | yximgs) |
    uicdn\.toast |
    unpkg |
    www\.(gstatic | layuicdn) |
    \w+\.googleapis
  )\.com |
  (
    bowercdn |
    craig\.global\.ssl\.fastly
  )\.net |
  [^\/.]+\.(
    github\.(io | com) |
    zstatic\.net
  )
)/`;
export const isDataUri = /*@__PURE__*/isDataUriRe.test.bind(isDataUriRe);
export const isValidHttpUrl = url => isHttpOrHttpsRe.test(url) && tryUrl(url);
export const isRemote = url => url && !isLocalUrlRe.test(decodeURI(url));

/** @returns {string|undefined} */
export function tryUrl(str, base) {
  try {
    if (str ?? base) {
      return new URL(str, base).href; // throws on invalid urls
    }
  } catch (e) {
    // undefined
  }
}

// Used by `injected`
const SIMPLE_VALUE_TYPE = {
  __proto__: null,
  string: 's',
  number: 'n',
  boolean: 'b',
};

// Used by `injected`
export function dumpScriptValue(value, jsonDump = JSON.stringify) {
  if (value !== undefined) {
    const simple = SIMPLE_VALUE_TYPE[typeof value];
    return `${simple || 'o'}${simple ? value : jsonDump(value)}`;
  }
}

export function normalizeTag(tag) {
  return tag.replace(/[^\w.-]/g, '');
}

export function escapeStringForRegExp(str) {
  return str.replace(/[\\.?+[\]{}()|^$]/g, '\\$&');
}

export function leaseBlobUrl(blob) {
  const url = URL.createObjectURL(blob);
  makePause(BLOB_LIFE, url).then(URL.revokeObjectURL);
  return url;
}

/**
 * @param {Blob} blob
 * @param {boolean | 'text'} [asBuffer]
 * @return {Promise<string|ArrayBuffer>}
 */
export function readBlob(blob, asBuffer) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    if (asBuffer === 'text') reader.readAsText(blob);
    else if (asBuffer) reader.readAsArrayBuffer(blob);
    else reader.readAsDataURL(blob);
  });
}
